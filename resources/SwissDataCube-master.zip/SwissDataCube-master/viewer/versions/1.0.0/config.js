var appConfig={
    'appVersion' : '1.0.0',
	'appVersionDate' : '[10.09.2018]',
	'gsHost' : 'https://geoserver.swissdatacube.org/geoserver/ows?',
	'mapZoom' : '8',
	'mapMinZoom' : '7',
	'mapMaxZoom' : '15',
	'mapCenter' : [46.78, 8.22],
};