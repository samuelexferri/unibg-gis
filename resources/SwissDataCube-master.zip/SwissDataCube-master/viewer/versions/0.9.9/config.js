var appConfig={
    'appVersion' : '0.9.9',
	'appVersionDate' : '[16.08.2018]',
	'gsHost' : 'https://geoserver.swissdatacube.org/geoserver/ows?',
	'mapZoom' : '8',
	'mapMinZoom' : '7',
	'mapMaxZoom' : '15',
	'mapCenter' : [46.78, 8.22],
};