# SEN2COR installation
```
wget http://step.esa.int/thirdparties/sen2cor/2.5.5/Sen2Cor-02.05.05-Linux64.run
bash Sen2Cor-02.05.05-Linux64.run --target ./aux/sen2cor205
/home/localuser/aux/sen2cor205/bin/L2A_Process # To test installation
rm Sen2Cor-02.05.05-Linux64.run
```
