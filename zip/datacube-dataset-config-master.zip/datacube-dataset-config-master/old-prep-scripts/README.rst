Deprecation Warning
==================================

The scripts in this directory are being reviewed and shifted to the new `Dataset Config <https://github.com/opendatacube/datacube-dataset-config>`__ repository.

Scripts that remain in this directory may be out of date, and should be considered deprecated.
