
Architecture Guide
##################

.. toctree::
   :maxdepth: 2

   intro.rst
   high_level.rst
   data_model.rst
   metadata_index.rst
   data_loading.rst
   driver.rst
