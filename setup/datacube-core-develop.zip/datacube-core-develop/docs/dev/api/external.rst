.. _dev-external:

External Classes
================


.. autoclass:: affine.Affine
    :members:
