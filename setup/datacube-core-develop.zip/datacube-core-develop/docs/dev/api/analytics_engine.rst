.. _dev-analytics:

Analytics and Execution Engines
===============================

The old Analytics and Execution Engines have been deprecated, but replacements
are taking shape inside the `execution engine branch`_ on GitHub. Check out the work there
for the latest updates.


.. _execution engine branch: https://github.com/opendatacube/datacube-core/compare/csiro/execution-engine
