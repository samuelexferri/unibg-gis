.. _license:

ODC License
***********

.. literalinclude:: ../../LICENSE
