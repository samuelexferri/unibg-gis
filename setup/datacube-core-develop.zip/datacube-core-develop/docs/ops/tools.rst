Command Line Tools
******************

.. contents::
   :local:

.. click:: datacube.scripts.cli_app:cli
   :prog: datacube
   :show-nested:

.. click:: datacube.scripts.search_tool:cli
   :prog: datacube-search
   :show-nested:

.. click:: datacube.execution.worker:main
   :prog: datacube-worker
   :show-nested:
