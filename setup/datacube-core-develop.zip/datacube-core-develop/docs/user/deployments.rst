
Existing Deployments
====================



Digital Earth Australia
-----------------------

If you are using `Digital Earth Australia`_ at the :term:`NCI`, see the
`Digital Earth Australia User Guide`_.

.. _`Digital Earth Australia`: http://www.ga.gov.au/dea
.. _`Digital Earth Australia User Guide`: http://geoscienceaustralia.github.io/digitalearthau/



Digital Earth Africa
--------------------
http://www.ga.gov.au/digitalearthafrica

Swiss Data Cube
---------------

https://www.swissdatacube.org/


Vietnam Open Data Cube
----------------------

http://datacube.vn/


.. note::

   This is not a comprehensive list.

..

    http://tinyurl.com/datacubeui