
.. _jupyter-notebooks:

Jupyter Notebooks
=================

For interactively exploring data in a Data Cube, we recommend using `Jupyter Notebooks`_.

.. _Jupyter Notebooks:


Several GitHub repositories of example Open Data Cube notebooks are available, showing
how to access data through ODC, along with example algorithms and visualisations.



 * https://github.com/ceos-seo/data_cube_notebooks


 * https://github.com/GeoscienceAustralia/dea-notebooks/




