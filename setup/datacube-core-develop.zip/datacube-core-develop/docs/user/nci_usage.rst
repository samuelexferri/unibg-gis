:orphan:

.. This file isn't referenced in the toctree, but is kept to maintain old hyperlinks.


.. highlight:: console

.. _nci_usage_guide:

NCI Usage Guide
***************

`Digital Earth Australia`_ is has replaced the :term:`AGDC` as the implementation of :term:`ODC`
at the :term:`NCI`.

For details on how to access the system, see the `Digital Earth Australia User Guide`_.


.. _`Digital Earth Australia`: http://www.ga.gov.au/dea
.. _`Digital Earth Australia User Guide`: http://geoscienceaustralia.github.io/digitalearthau/