### Expected behaviour


### Actual behaviour

... eg. Incorrect result, python stacktrace, etc. ...


### Steps to reproduce the behaviour

... Include code, command line parameters as appropriate ...

### Environment information

* Which ``datacube --version`` are you using?
* What datacube deployment/enviornment are you running against?
